package com.dh.hrmanager.view.manager;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import javax.swing.JToolBar;

import com.dh.hrmanager.db.ReportDao;
import com.dh.hrmanager.entity.Employee;
import com.dh.hrmanager.view.comm.MainBaseFrame;
import com.dh.hrmanager.view.comm.ModifyPassword;
import com.dh.hrmanager.view.comm.PrivateInfo;

public class ManagerMain extends MainBaseFrame {

	private static final long serialVersionUID = 1L;
	ReportDao rd  = new ReportDao();
	public ManagerMain(Employee emp){
		super(emp);
		setTitle("�����������");
		JMenu functionMenu = getMenuFunction();
		JToolBar tbTop = getToolBarTop();
		JToolBar tbBottom = getToolBarBottom();
		JTable employeeTable = getContentTable();
		
		ActionListener reportListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DisplayReport dp = new DisplayReport(getCurrentEmp());
				dp.setVisible(true);
			}
		};
		ActionListener evaluationListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EvaluatedEmployee ee = new EvaluatedEmployee(getCurrentEmp());
				ee.setVisible(true);
			}
		};
		ActionListener displayEmployeesListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DisplayEmployees de = new DisplayEmployees(getCurrentEmp());
				de.setVisible(true);
			}
		};
		ActionListener privateListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PrivateInfo pi = new PrivateInfo(getCurrentEmp());
				pi.setVisible(true);
			}
		};
		ActionListener modifyPasswordListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ModifyPassword mp = new ModifyPassword(getCurrentEmp());
				mp.setVisible(true);
			}
		};
		
		
		JMenuItem miReport = new JMenuItem("�鿴�����㱨");
		miReport.addActionListener(reportListener);
		functionMenu.add(miReport);

		JMenuItem miEvaluation = new JMenuItem("����Ա��");
		miEvaluation.addActionListener(evaluationListener);
		functionMenu.add(miEvaluation);

		JMenuItem miDispalyEmployees = new JMenuItem("�鿴����Ա����Ϣ");
		miDispalyEmployees.addActionListener(displayEmployeesListener);
		functionMenu.add(miDispalyEmployees);
		
		JMenuItem miDisplaySelfInfo = new JMenuItem("�鿴������Ϣ");
		miDisplaySelfInfo.addActionListener(privateListener);
		functionMenu.add(miDisplaySelfInfo);

		JMenuItem miModifyPassword = new JMenuItem("�޸�����");
		miModifyPassword.addActionListener(modifyPasswordListener);
		functionMenu.add(miModifyPassword);
		
		JButton btnReport= new JButton("�鿴�����㱨");
		tbTop.add(btnReport);
		btnReport.addActionListener(reportListener);
		
		
		JButton btnEvaluation = new JButton("����Ա��");
		tbTop.add(btnEvaluation);
		btnEvaluation.addActionListener(evaluationListener);
		
		JButton btnDispalyEmployees = new JButton("�鿴����Ա����Ϣ");
		tbTop.add(btnDispalyEmployees);
		btnDispalyEmployees.addActionListener(displayEmployeesListener);
		
		JButton btnDisplaySelfInfo = new JButton("�鿴������Ϣ");
		btnDisplaySelfInfo.addActionListener(privateListener);
		tbTop.add(btnDisplaySelfInfo);

		JButton btnModifyPassword = new JButton("�޸�����");
		btnModifyPassword.addActionListener(modifyPasswordListener);
		tbTop.add(btnModifyPassword);
		
		try {
			rd.fillReportsToTable(getCurrentEmp(), employeeTable, new String[]{
					"�㱨��",
					"�㱨����"
			}, 2);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			e1.printStackTrace();
		}
		
		JLabel lblUserInfo1 = new JLabel("��ǰ��½�û�:" + emp.getUserName());
		JLabel lblUserInfo2 = new JLabel("��ǰ��ɫ��Manager");
		tbBottom.add(lblUserInfo1, BorderLayout.WEST);
		tbBottom.add(lblUserInfo2, BorderLayout.EAST);
	}
}
