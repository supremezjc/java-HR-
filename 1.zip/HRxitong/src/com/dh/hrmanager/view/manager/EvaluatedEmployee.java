package com.dh.hrmanager.view.manager;

public class EvaluatedEmployee {

}
