package com.dh.hrmanager.view.admin;

public class ModifyEmployeeRole {

}
