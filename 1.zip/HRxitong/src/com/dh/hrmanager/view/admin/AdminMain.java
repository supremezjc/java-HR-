package com.dh.hrmanager.view.admin;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import javax.swing.JToolBar;

import com.dh.hrmanager.db.UserDao;
import com.dh.hrmanager.entity.Employee;
import com.dh.hrmanager.view.comm.MainBaseFrame;
import com.dh.hrmanager.view.comm.ModifyPassword;
import com.dh.hrmanager.view.comm.PrivateInfo;

public class AdminMain extends MainBaseFrame {

	private static final long serialVersionUID = 1L;
	UserDao ud = new UserDao();
	JTable employeeTable;
	
	public AdminMain(Employee emp) {
		super(emp);
		setTitle("����Ա�������");
		JMenu functionMenu = getMenuFunction();
		JToolBar tbTop = getToolBarTop();
		JToolBar tbBottom = getToolBarBottom();
		employeeTable = getContentTable();
		
		//�¼�������
		ActionListener createEmployeeListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AddEmployee ae = new AddEmployee(getCurrentEmp(), AdminMain.this);
				ae.setVisible(true);
			}
		};
		ActionListener modifyRoleListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ModifyEmployeeRole mer = new ModifyEmployeeRole(getCurrentEmp());
				mer.setVisible(true);
			}
		};
		ActionListener privateListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PrivateInfo pi = new PrivateInfo(getCurrentEmp());
				pi.setVisible(true);
			}
		};
		
		ActionListener modifyPasswordListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ModifyPassword mp = new ModifyPassword(getCurrentEmp());
				mp.setVisible(true);
			}
		};

		JMenuItem miAddEmployee = new JMenuItem("����Ա��");
		miAddEmployee.addActionListener(createEmployeeListener);
		functionMenu.add(miAddEmployee);
		

		JMenuItem miModifyEmployeeRole = new JMenuItem("�޸�Ա����ɫ");
		miModifyEmployeeRole.addActionListener(modifyRoleListener);
		functionMenu.add(miModifyEmployeeRole);

		JMenuItem miDisplayEmployeeInfo = new JMenuItem("�鿴������Ϣ");
		miDisplayEmployeeInfo.addActionListener(privateListener);
		functionMenu.add(miDisplayEmployeeInfo);

		JMenuItem miModifyPassword = new JMenuItem("�޸�����");
		miModifyPassword.addActionListener(modifyPasswordListener);
		functionMenu.add(miModifyPassword);
		
		JButton btnAddEmployee = new JButton("����Ա��");
		btnAddEmployee.addActionListener(createEmployeeListener);
		tbTop.add(btnAddEmployee);
		
		JButton btnModifyEmployeeRole = new JButton("�޸�Ա����ɫ");
		btnModifyEmployeeRole.addActionListener(modifyRoleListener);
		tbTop.add(btnModifyEmployeeRole);
		
		JButton btnDisplayEmployeeInfo = new JButton("�鿴������Ϣ");
		btnDisplayEmployeeInfo.addActionListener(privateListener);
		tbTop.add(btnDisplayEmployeeInfo);
		
		JButton btnModifyPassword = new JButton("�޸�����");
		btnModifyPassword.addActionListener(modifyPasswordListener);
		tbTop.add(btnModifyPassword);

		try {
			//������Ա����Ϣ��䵽����
			ud.fillEmployeesToTable(0, employeeTable, new String[]{
					"Ա�����",
					"����",
					"ְ��",
					"����"
				});
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			e1.printStackTrace();
		}
		//״̬��
		JLabel lblUserInfo1 = new JLabel("��ǰ��½�û�:" + emp.getUserName());
		JLabel lblUserInfo2 = new JLabel("��ǰ��ɫ��Admin");
		tbBottom.add(lblUserInfo1, BorderLayout.WEST);
		tbBottom.add(lblUserInfo2, BorderLayout.EAST);
		
	}
	public void reFillTable(){
		try {
			ud.fillEmployeesToTable(0, employeeTable, new String[]{
					"Ա�����",
					"����",
					"ְ��",
					"����"
				});
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			e1.printStackTrace();
		}
	}
}
