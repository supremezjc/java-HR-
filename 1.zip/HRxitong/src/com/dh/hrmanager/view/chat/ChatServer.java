package com.dh.hrmanager.view.chat;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import com.dh.hrmanager.entity.User;
import com.dh.hrmanager.util.Config;
public class ChatServer extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JSplitPane splitPaneV, splitPaneH;
	private JScrollPane spCenter, spRight;
	private JPanel pdown;
	private JTextArea txtContent;
	private JLabel lblSend;
	private JTextField txtSend;
	private JButton btnSend;
	private DefaultMutableTreeNode root;
	private DefaultTreeModel model;
	private JTree tree;

	private String fileName = "chat.properties";
	private ServerSocket msgServerSocket;// ��Ϣ�����׽���
	private ServerSocket userServerSocket;// �û������׽���

	private ArrayList<Socket> msgSocket = new ArrayList<Socket>();
	private ArrayList<PrintWriter> printWriter = new ArrayList<PrintWriter>();
	private ArrayList<BufferedReader> bufferedReader 
			= new ArrayList<BufferedReader>();
	private LinkedList<String> msgList = new LinkedList<String>();

	private ArrayList<Socket> userSocket = new ArrayList<Socket>();
	private ArrayList<PrintWriter> printUser = new ArrayList<PrintWriter>();
	private ArrayList<ObjectInputStream> readUser 
			= new ArrayList<ObjectInputStream>();
	private ArrayList<User> userList = new ArrayList<User>();
	private static boolean isRun = true; // �����߳��Ƿ�����

	public ChatServer() throws Exception {
		super("������");
		txtContent = new JTextArea();
		txtContent.setEditable(false);
		spCenter = new JScrollPane(txtContent);
		pdown = new JPanel();
		lblSend = new JLabel("ϵͳ��Ϣ��");
		txtSend = new JTextField(20);
		btnSend = new JButton("����");
		pdown.add(lblSend);
		pdown.add(txtSend);
		pdown.add(btnSend);
		btnSend.addActionListener(this);
		root = new DefaultMutableTreeNode("Ŀǰ�����û�(�û����:�û���)");
		model = new DefaultTreeModel(root);
		tree = new JTree(model);
		spRight = new JScrollPane(tree);
		splitPaneV = new JSplitPane(JSplitPane.VERTICAL_SPLIT, spCenter, pdown);
		splitPaneV.setDividerLocation(420);
		splitPaneH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, splitPaneV,spRight);
		splitPaneH.setDividerLocation(400);

		this.add(splitPaneH);
		this.setSize(600, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(new WindowEventHandle());

		msgServerSocket = new ServerSocket(Integer.parseInt(Config.getValueByFileName(fileName,"msgport")));
		userServerSocket = new ServerSocket(Integer.parseInt(Config.getValueByFileName(fileName,"userport")));
		new AcceptUserSocketThread().start(); // ���������û��׽��ֵ��߳�
		new AcceptMsgSocketThread().start();// ����������Ϣ�׽��ֵ��߳�
		new SendMessageThread().start();// ����������Ϣ�׽��ֵ��߳�
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnSend) {
			String str = txtSend.getText();
			if (!str.equals("")) {
				msgList.addFirst("ϵͳ��Ϣ��" + str);
			}
		}
	}
	// ���տͻ��˷��͵��й��û��׽��ֵ��߳�
	class AcceptUserSocketThread extends Thread {
		public void run() {
			while (isRun) {
				try {
					Socket socket = userServerSocket.accept();
					ObjectInputStream readerFromClient = new ObjectInputStream(
							socket.getInputStream());
					PrintWriter printToClient = new PrintWriter(
							socket.getOutputStream());
					printUser.add(printToClient);

					User user = (User) readerFromClient.readObject();
					if (user != null) {
						userList.add(user);
						// �ڸ��ڵ�������һ�½ڵ�
						root.add(new DefaultMutableTreeNode(user.getUserNo() + ":" + user.getUserName()));
						tree.setModel(model); // ˢ����
						tree.updateUI();
						sendUserListToClient();//�����пͻ��˷���Ŀǰ�����û���Ϣ
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	// �����пͻ��˷���Ŀǰ�����û���Ϣ
	private void sendUserListToClient() {
		String people = "";
		for (int i = 0; i < userList.size(); i++) {
			people += "&" + userList.get(i).getUserName() ;
		}
		for (int i = 0; i < printUser.size(); i++) {
			if (printUser.get(i) != null) {
				try {
					printUser.get(i).println(people);
					printUser.get(i).flush();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	// ���տͻ��˷��͵��й���Ϣ�׽��ֵ��߳�
	class AcceptMsgSocketThread extends Thread {
		public void run() {
			while (isRun) {
				try {
					Socket socket = msgServerSocket.accept();
					BufferedReader bufferedFromClient = new BufferedReader(
							new InputStreamReader(socket.getInputStream(),"GB2312"));
					PrintWriter printWriterToClient = new PrintWriter(
							socket.getOutputStream());
					printWriter.add(printWriterToClient);
					bufferedReader.add(bufferedFromClient);
					// �������մ˿ͻ�����������Ϣ���߳�
					new GetMessageThread(bufferedFromClient).start();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	// ���տͻ�������Ϣ���߳�
	class GetMessageThread extends Thread {
		private String stringFromClient = null;
		private BufferedReader bufferedReaderFromClient;
		public GetMessageThread(BufferedReader buffer) throws Exception {
			bufferedReaderFromClient = buffer;
		}

		public void run() {
			try {
				do {
					stringFromClient = bufferedReaderFromClient.readLine();
					msgList.addFirst(stringFromClient);
				} while (!stringFromClient.toLowerCase().endsWith("bye"));
				int index = bufferedReader.indexOf(bufferedReaderFromClient);
				bufferedReader.remove(index);
				printWriter.remove(index);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	// �����ÿͻ��˷�����Ϣ���߳�
	class SendMessageThread extends Thread {
		public SendMessageThread() throws Exception {
			super();
		}
		public void run() {
			while (isRun) {
				try {
					String s = null;
					if (!msgList.isEmpty()) {
						s = (String) msgList.removeLast();
						txtContent.append(s + "\n");
						for (int i = 0; i < printWriter.size(); i++) {
							if (printWriter.get(i) != null) {
								printWriter.get(i).println(s);
								printWriter.get(i).flush();
							}
						}
					} else {
						sleep(100);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	// ���������
	class WindowEventHandle extends WindowAdapter {
		// ������ر�ʱ��ֹͣ����ͨ���߳�
		public void windowClosing(WindowEvent e) {
			isRun = false;
			try {
				msgServerSocket.close();
				userServerSocket.close();
				for (int i = 0; i < msgSocket.size(); i++) {
					msgSocket.get(i).close();
				}
				for (int i = 0; i < printWriter.size(); i++) {
					printWriter.get(i).close();
				}
				for (int i = 0; i < bufferedReader.size(); i++) {
					bufferedReader.get(i).close();
				}
				for (int i = 0; i < userSocket.size(); i++) {
					userSocket.get(i).close();
				}
				for (int i = 0; i < printUser.size(); i++) {
					printUser.get(i).close();
				}
				for (int i = 0; i < readUser.size(); i++) {
					readUser.get(i).close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			} finally {
				msgServerSocket = null;
				userServerSocket = null;
				msgSocket = null;
				printWriter = null;
				bufferedReader = null;
				msgList = null;
				userSocket = null;
				printUser = null;
				readUser = null;
				userList = null;
			}
		}
	}
	public static void main(String args[]) throws Exception {
		ChatServer chatServer = new ChatServer();
		chatServer.setVisible(true);
	}
}
