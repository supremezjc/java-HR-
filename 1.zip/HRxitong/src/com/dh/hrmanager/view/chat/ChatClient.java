package com.dh.hrmanager.view.chat;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.StringTokenizer;
import javax.swing.*;
import com.dh.hrmanager.entity.User;
import com.dh.hrmanager.util.Config;
public class ChatClient extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	public static String username = "";// ��ǰ�����û����û���
	public static String empNo = "";// ��ǰ�����û��ı��
	private JSplitPane splitPaneV, splitPaneH;
	private JScrollPane spCenter;
	private JPanel pRight;
	private JPanel pdown;
	private JTextArea txtContent;
	private JLabel lblSend;
	private JTextField txtSend;
	private JButton btnSend;
	private String fileName = "chat.properties";
	private Socket socketMsg;// ������Ϣ���ݵ��׽���
	private Socket socketUser;// �û��û����ݵ��׽���
	private PrintWriter printMsg;
	private BufferedReader readMsg;
	private ObjectOutputStream printUser;
	private BufferedReader readUser;
	private String strMsg = null;
	public ChatClient() {
		super("������");
		txtContent = new JTextArea();
		txtContent.setEditable(false);
		spCenter = new JScrollPane(txtContent);
		pdown = new JPanel();
		lblSend = new JLabel("���룺");
		txtSend = new JTextField(20);
		btnSend = new JButton("����");
		pdown.add(lblSend);
		pdown.add(txtSend);
		pdown.add(btnSend);
		btnSend.addActionListener(this);
		pRight = new JPanel(null);
		splitPaneV = new JSplitPane(
					JSplitPane.VERTICAL_SPLIT, spCenter, pdown);
		splitPaneV.setDividerLocation(320);
		splitPaneH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
		 splitPaneV,pRight);
		splitPaneH.setDividerLocation(350);
		this.add(splitPaneH);
		this.setSize(500, 400);
		this.setLocation(300, 300);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addWindowListener(new WindowEventHandle());
		createUserListConnection();
		createMsgConnection();
		new GetUserListFromServer().start();
		new GetMsgFromServer().start();
	}
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == btnSend) {
			String str = txtSend.getText();
			if (!str.equals("")) {
				// ����ͨ��
				printMsg.println(username + "˵:" + str);
				printMsg.flush();
				txtSend.setText("");
			}
		}
	}
	// ���������
	class WindowEventHandle extends WindowAdapter {
		// ������ر�ʱ��ͬʱ�ر�����ͨ������
		public void windowClosing(WindowEvent e) {
			closeConnection();
		}
	}
	// �ر�����ͨ������
	private void closeConnection() {
		try {
			printMsg.println(username + "˵:bye�����ȹ�����");
			printMsg.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// ����������Ϣ����
	private void createMsgConnection() {
		try {
			socketMsg = new Socket(
					Config.getValueByFileName(fileName,"server"),
		Integer.parseInt(Config.getValueByFileName(fileName,"msgport")));
			printMsg = new PrintWriter(
						socketMsg.getOutputStream(), true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// �����û���Ϣ����
	private void createUserListConnection() {
		try {
			socketUser = new Socket(
					Config.getValueByFileName(fileName,"server"),
	Integer.parseInt(Config.getValueByFileName(fileName,"userport")));
			printUser = new ObjectOutputStream(
								socketUser.getOutputStream());
			// ��װ��ǰ�û�����Ϣ
			User user = new User(empNo,username); 
			// ����ǰ�û����͸�������
			printUser.writeObject((User) user);
			printUser.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// �ӷ�������ȡ������Ϣ���߳�
	class GetMsgFromServer extends Thread {
		public void run() {
			try {
				readMsg = new BufferedReader(new InputStreamReader(
						socketMsg.getInputStream(),"GB2312"));
				do {
					strMsg = readMsg.readLine();
					// ���ı�����ʾ������Ϣ
					txtContent.append(strMsg + "\n");
				} while (strMsg != null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	// �ӷ�������ȡ���������û���Ϣ���߳�
	class GetUserListFromServer extends Thread {
		public void run() {
			try {
				readUser = new BufferedReader(new InputStreamReader(
						socketUser.getInputStream()));
				do {
					String line = readUser.readLine();
					if (line != null) {
						StringTokenizer st 
								= new StringTokenizer(line, "&");
						pRight.removeAll();
						int y = 10;
						while (st.hasMoreTokens()) {
							String name = st.nextToken();
							JLabel userNode = new JLabel(
										name, JLabel.LEFT);
							userNode.setBounds(10, y, 60, 40);
							pRight.add(userNode);
							y += 45;
						}
						pRight.setSize(150, 300);
						splitPaneH.setDividerLocation(350);
						ChatClient.this.setSize(0, 0);
						ChatClient.this.setSize(500, 400);
					}
				} while (true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
