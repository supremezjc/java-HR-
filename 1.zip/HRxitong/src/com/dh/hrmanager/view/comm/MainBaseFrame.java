package com.dh.hrmanager.view.comm;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;

import com.dh.hrmanager.entity.Employee;
//�����������
public class MainBaseFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	//�������
	private JPanel pnlBackGround;
	//�˵�����
	private JMenuBar topMenuBar;
	//���ܹ����˵�
	private JMenu menuFunction;
	//ϵͳ�����˵�
	private JMenu menuSysoper;
	//���µ�¼�˵���
	private JMenuItem miReLogin;
	//����
	private JTable contentTable;
	//���˹�����
	private JToolBar toolBarTop;
	//�׶�״̬������
	private JToolBar toolBarBottom;
	//��������
	private JScrollPane sp;
	//��ǰ��¼Ա��
	private Employee currentEmp;
	private void init(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		//�˵�����
		topMenuBar = new JMenuBar();
		setJMenuBar(topMenuBar);
		//�����˵�
		menuFunction = new JMenu("���ܹ���");
		topMenuBar.add(menuFunction);
		menuSysoper = new JMenu("ϵͳ����");
		topMenuBar.add(menuSysoper);
		miReLogin = new JMenuItem("���µ�¼");
		menuSysoper.add(miReLogin);
		miReLogin.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				Login login = new Login();
				login.setVisible(true);
				MainBaseFrame.this.setVisible(false);
			}
		});
		//�������
		pnlBackGround = new JPanel();
		setContentPane(pnlBackGround);
		pnlBackGround.setLayout(new BorderLayout());
		//������������ͣ����ܶ���
		toolBarTop = new JToolBar();
		pnlBackGround.add(toolBarTop, BorderLayout.PAGE_START);
		//��������
		contentTable = new JTable();
		sp = new JScrollPane(contentTable);
		pnlBackGround.add(sp, BorderLayout.CENTER);
		//������ܵ׶�״̬��
		toolBarBottom = new JToolBar();
		toolBarBottom.setLayout(new BorderLayout());
		pnlBackGround.add(toolBarBottom, BorderLayout.PAGE_END);
	}
	public MainBaseFrame(){
		init();
	}
	//emp��ǰ��¼Ա��
	public MainBaseFrame(Employee emp){
		init();
		setCurrentEmp(emp);
	}
	public JPanel getPnlBackGround() {
		return pnlBackGround;
	}
	public void setPnlBackGround(JPanel pnlBackGround) {
		this.pnlBackGround = pnlBackGround;
	}
	public JMenuBar getTopMenuBar() {
		return topMenuBar;
	}
	public void setTopMenuBar(JMenuBar topMenuBar) {
		this.topMenuBar = topMenuBar;
	}
	public JMenu getMenuFunction() {
		return menuFunction;
	}
	public void setMenuFunction(JMenu menuFunction) {
		this.menuFunction = menuFunction;
	}
	public JMenu getMenuSysoper() {
		return menuSysoper;
	}
	public void setMenuSysoper(JMenu menuSysoper) {
		this.menuSysoper = menuSysoper;
	}
	public JMenuItem getMiReLogin() {
		return miReLogin;
	}
	public void setMiReLogin(JMenuItem miReLogin) {
		this.miReLogin = miReLogin;
	}
	public JTable getContentTable() {
		return contentTable;
	}
	public void setContentTable(JTable contentTable) {
		this.contentTable = contentTable;
	}
	public JToolBar getToolBarTop() {
		return toolBarTop;
	}
	public void setToolBarTop(JToolBar toolBarTop) {
		this.toolBarTop = toolBarTop;
	}
	public JToolBar getToolBarBottom() {
		return toolBarBottom;
	}
	public void setToolBarBottom(JToolBar toolBarBottom) {
		this.toolBarBottom = toolBarBottom;
	}
	public JScrollPane getSp() {
		return sp;
	}
	public void setSp(JScrollPane sp) {
		this.sp = sp;
	}
	public Employee getCurrentEmp() {
		return currentEmp;
	}
	public void setCurrentEmp(Employee currentEmp) {
		this.currentEmp = currentEmp;
	}
}
