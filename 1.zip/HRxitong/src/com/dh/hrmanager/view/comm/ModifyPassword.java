package com.dh.hrmanager.view.comm;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;

import com.dh.hrmanager.db.UserDao;
import com.dh.hrmanager.entity.Employee;
import com.dh.hrmanager.util.SwingHrHelper;

//�����Զ���BaseFrame�����ɣ����Ч��
public class ModifyPassword extends BaseFrame {
	private static final long serialVersionUID = 1L;
	private JLabel lblOldPassword;
	private JLabel lblNewPassword;
	private JLabel lblConfirmPassword;
	
	private JPasswordField txtOldPassword;
	private JPasswordField txtNewPassword;
	private JPasswordField txtConfirmPassword;
	
	private JButton btnModify;
	//����ҵ���߼���
	SwingHrHelper helper = new SwingHrHelper();
	UserDao userDao = new UserDao();
	public ModifyPassword(Employee emp){
		super(emp);
		//��������ܼ���������С��λ��
		helper.setInit(this, 420, 350, 20, 20, 340, 310, "�޸�����");	
		
		//ʵ����
		lblOldPassword = new JLabel();
		lblNewPassword = new JLabel();
		lblConfirmPassword = new JLabel();
		txtOldPassword = new JPasswordField();
		txtNewPassword = new JPasswordField();;
		txtConfirmPassword = new JPasswordField();;
		btnModify = new JButton();
		btnModify.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent ex) {
				// TODO Auto-generated method stub
				String pass1 = new String(txtNewPassword.getPassword());
				String pass2 = new String(txtConfirmPassword.getPassword());
				String oldPass = new String(txtOldPassword.getPassword());
				if(!oldPass.equals(getCurrentEmp().getPassword())){
					JOptionPane.showMessageDialog(btnModify, "ԭʼ���벻��ȷ");
					txtOldPassword.requestFocus();
					return;
				}
				if(!pass1.equals(pass2)){
					JOptionPane.showMessageDialog(btnModify, "������ȷ�����벻��ͬ");
					lblNewPassword.requestFocus();
					return;
				}
				try {
					userDao.modifyPassword(getCurrentEmp(), new String(txtNewPassword.getPassword()));
					JOptionPane.showMessageDialog(btnModify, "�޸ĳɹ�");
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(btnModify, "�޸�ʧ��");
				} catch (InstantiationException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}
			
		});
		//�õ��������
		JPanel pnl = getPnlBackGround();
		
		//����������м���ؼ������ÿؼ�����
		helper.addComponent(pnl, lblOldPassword, 60, 40, 48, 15, "������:");
		helper.addComponent(pnl, lblNewPassword, 60, 90, 48, 15, "������:");
		helper.addComponent(pnl, lblConfirmPassword, 48, 140, 60, 15, "ȷ������:");
		//����ɱ༭�ı���		
		helper.addComponent(pnl, txtOldPassword, 110, 36, 160, 21, null);
		helper.addComponent(pnl, txtNewPassword, 110, 86, 160, 21, null);
		helper.addComponent(pnl, txtConfirmPassword, 110, 136, 160, 21, null);
		//���밴ť
		helper.addComponent(pnl, btnModify, 120, 210, 60, 23, "�޸�");
		
	}
	
}
