package com.dh.hrmanager.view.staff;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.dh.hrmanager.db.ReportDao;
import com.dh.hrmanager.db.UserDao;
import com.dh.hrmanager.entity.Employee;
import com.dh.hrmanager.entity.Manager;
import com.dh.hrmanager.entity.Report;
import com.dh.hrmanager.util.SwingHrHelper;
import com.dh.hrmanager.view.comm.BaseFrame;
public class StaffReport extends BaseFrame {
	private JLabel lblReporterEmpNo;
	private JLabel lblReporterName;
	private JLabel lblReportManager;
	private JLabel lblReportContent;
	private JTextField txtReporterEmpNo;
	private JTextField txtReporterName;
	private JTextField txtReportManager;
	private JTextArea  txtReportContent;
	private JScrollPane sp;
	private JButton btnSubmit;
	private StaffMain staffMain;
	Manager manager = null;
	UserDao userDao = new UserDao();
	ReportDao rd = new ReportDao();
	//Swing����ҵ���߼��࣬����μ�
	SwingHrHelper helper = new SwingHrHelper();
	public StaffReport(Employee emp, StaffMain parent){
		super(emp);
		//���ó�ʼ��ܼ�����С
		helper.setInit(this, 460, 400, 0, 0, 460, 400, "�㱨����");
		staffMain = parent;
		lblReporterEmpNo = new JLabel();
		lblReporterName = new JLabel();
		lblReportManager = new JLabel();
		lblReportContent = new JLabel();
		txtReporterEmpNo = new JTextField();
		txtReporterEmpNo.setText(getCurrentEmp().getEmpNo());
		txtReporterName = new JTextField();
		txtReporterName.setText(getCurrentEmp().getUserName());
		try {
			manager = userDao.getDepartmentManagerByUserId(emp.getUserId());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		txtReportManager = new JTextField();
		if(manager != null)
			txtReportManager.setText(manager.getUserName());
		//���������ı����ܱ༭
		helper.setComponentEnabled(false, new JComponent[]{
				txtReporterEmpNo,txtReporterName,txtReportManager});
		txtReportContent = new JTextArea();
		txtReportContent.setColumns(20);
		txtReportContent.setRows(5);
		sp = new JScrollPane();
		sp.setViewportView(txtReportContent);
		btnSubmit = new JButton();
		btnSubmit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				Report report = new Report(0, getCurrentEmp().getUserId(), 
					txtReportContent.getText(),LocalDate.now().toString());
				int affectedCount = 0;
				try {
					affectedCount = rd.addReport(report);
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (InstantiationException e1) {
					e1.printStackTrace();
				} catch (IllegalAccessException e1) {
					e1.printStackTrace();
				}
				if( affectedCount > 0){
					JOptionPane.showMessageDialog(StaffReport.this.btnSubmit, 
						"�㱨�ɹ�");
					StaffReport.this.setVisible(false);
					staffMain.reFillTable();
				}
				else
					JOptionPane.showMessageDialog(StaffReport.this.btnSubmit, 
						"�㱨ʧ��");
			}
		});
		//panel����
		JPanel pnl = getPnlBackGround();
		//���ñ�ǩ���֣�����ҵ���߼����еķ���
		helper.addComponent(pnl, lblReporterEmpNo, 36, 38, 72, 15, "�㱨�˱��:");
		helper.addComponent(pnl, lblReporterName, 60, 77, 48, 15, "�㱨��:");
		helper.addComponent(pnl, lblReportManager, 50, 115, 60, 15, "�㱨����:");
		helper.addComponent(pnl, lblReportContent, 50, 151, 60, 15, "�㱨����:");
		//��������ؼ����֣�����ҵ���߼����еķ���
		helper.addComponent(pnl, txtReporterEmpNo, 118, 35, 175, 21, null);
		helper.addComponent(pnl, txtReporterName, 118, 74, 175, 21, null);
		helper.addComponent(pnl, txtReportManager, 118, 112, 175, 21, null);	
		helper.addComponent(pnl, sp, 118, 163, 299, 146, null);
		//��ť
		helper.addComponent(pnl, btnSubmit, 174, 330, 81, 23, "�ύ");
	}
}
