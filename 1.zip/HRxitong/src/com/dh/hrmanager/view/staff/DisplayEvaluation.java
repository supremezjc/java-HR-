package com.dh.hrmanager.view.staff;
import java.awt.BorderLayout;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import com.dh.hrmanager.db.EvaluationDao;
import com.dh.hrmanager.entity.Employee;
public class DisplayEvaluation extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tbContent;
	private JScrollPane sp;
	Employee employee;
	EvaluationDao rd = new EvaluationDao();
	public DisplayEvaluation(Employee emp){
		setTitle("�鿴����ɼ�");
		employee = emp;
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0,0));
		JLabel lblInfo = new JLabel(employee.getUserName() + "����ɼ����£�");
		contentPane.add(lblInfo,BorderLayout.NORTH);
		tbContent = new JTable();
		try {
			rd.fillReportsToTable(employee, tbContent,
					new String[]{"��������","����ɼ�","���⾭��","��������"}, 2);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		sp = new JScrollPane(tbContent);
		contentPane.add(sp, BorderLayout.CENTER);
	}
}
