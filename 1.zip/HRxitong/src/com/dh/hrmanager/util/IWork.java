package com.dh.hrmanager.util;

public interface IWork {
	void doWork();
}
