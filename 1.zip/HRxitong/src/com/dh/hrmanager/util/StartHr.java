package com.dh.hrmanager.util;

import com.dh.hrmanager.view.comm.Login;
public class StartHr {
	public static void main(String[] args) {
		Login login = new Login();
		login.setVisible(true);
	}
}
