package com.dh.hrmanager.entity;

import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class EditTable extends DefaultTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("rawtypes")
	public EditTable(Vector d, Vector n){
		super(d,n);
	}
	public boolean isCellEditable(int r, int c){
		return false;
	}
}
