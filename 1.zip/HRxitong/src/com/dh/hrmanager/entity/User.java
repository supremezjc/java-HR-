package com.dh.hrmanager.entity;
import java.io.Serializable;
//Ϊ��������������Ϳͻ��˴���ʵ�����л�
public class User extends Employee implements Serializable {
	private String userNo;
	private String userName;
	public User(String userNo, String userName) {
		super();
		this.userNo = userNo;
		this.userName = userName;
	}
	@Override
	public void doWork() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void displaySalaryRange() {
		// TODO Auto-generated method stub
		
	}
	public String getUserNo() {
		return userNo;
	}
	public void setUserNo(String userNo) {
		this.userNo = userNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
