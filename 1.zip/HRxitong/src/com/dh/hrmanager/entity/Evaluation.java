package com.dh.hrmanager.entity;
import java.io.Serializable;


//������,ʵ�ֱȽ�������������
@SuppressWarnings("serial")
public class Evaluation implements Comparable<Evaluation>, Serializable  {
	//����ID
	private int evaluationId;
	//������ID,������ɫ
	private int evaluatorId;
	//��������ID
	private int evaluatedId;
	private double score;
	
	public Evaluation(){
	}
	
	public Evaluation(int evaluationId, int evaluatorId, int evaluatedId, double score){
		this.evaluationId = evaluationId;
		this.evaluatorId = evaluatorId;
		this.evaluatedId = evaluatedId;
		this.score = score;
	}
	
	public int getEvaluationId() {
		return evaluationId;
	}
	public void setEvaluationId(int evaluationId) {
		this.evaluationId = evaluationId;
	}
	public int getEvaluatorId() {
		return evaluatorId;
	}

	public void setEvaluatorId(int evaluatorId) {
		this.evaluatorId = evaluatorId;
	}
	
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}

	public int getEvaluatedId() {
		return evaluatedId;
	}

	public void setEvaluatedId(int evaluatedId) {
		this.evaluatedId = evaluatedId;
	}	
	
	@Override
	public int compareTo(Evaluation o) {
		if(this.score > o.score)
			return -1;
		if(this.score < o.score)
			return 1;
		return 0;
	}
}
