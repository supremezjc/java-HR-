package com.dh.hrmanager.entity;

import com.dh.hrmanager.util.HrHelper;

public class Admin extends Employee {
	HrHelper helper = new HrHelper();
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(int userId, String empNo, String userName, String password,
			int departId, int roleId, double salary) {
		super(userId, empNo, userName, password, departId, roleId, salary);
		// TODO Auto-generated constructor stub
	}
	/**
	 * �޸�Ա����ɫ
	 * @param empNo Ա�����
	 * @param role  ��ɫ���ƣ�ֻ����Staff, Manager, Admin
	 */
	public void modifyEmployeeRole(String empNo, String role){
		helper.modifyEmployeeRole(empNo, role);
	}
	/**
	 * ��ʾԱ����Ϣ
	 * @param employee
	 */
	public void displayEmployeeInfo(Employee employee){
		helper.displayEmployeeInfo(employee);
	}
	
	
	
	@Override
	public void displaySalaryRange() {
		// TODO Auto-generated method stub
		System.out.println("Admin н�ʷ�ΧΪ:4000-6000");
	}
	
	//ʵ���ճ̽ӿ�
		@Override
		public void doWork() {
			// TODO Auto-generated method stub
			System.out.println(helper.getDate() + ",Admin����������:");
			System.out.println("********************************");
			System.out.println("\tά��Ա����Ϣ��");
		}
}
