package com.dh.hrmanager.entity;

import com.dh.hrmanager.util.HrHelper;

public class Manager extends Employee {
	HrHelper helper = new HrHelper();
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Manager(int userId, String empNo, String userName, String password,
			int departId, int roleId, double salary) {
		super(userId, empNo, userName, password, departId, roleId, salary);
		// TODO Auto-generated constructor stub
	}
	/**
	 * ��ʾ���л㱨
	 */
	public void displayReports(){
		helper.displayReports();
	}
	/**
	 * ��������
	 * @param evaluation
	 */
	public void addEvaluation(Evaluation evaluation){
		helper.addEvaluation(evaluation);
	}
	@Override
	public void displaySalaryRange() {
		System.out.println("Manangerн�ʷ�ΧΪ��5000-7000");
	}
	//ʵ�ֹ������Žӿ�
	@Override
	public void doWork() {
		System.out.println(helper.getDate() + ",Manager����������:");
		System.out.println("=============================");
		System.out.println("\t�ƶ�����ƻ���");
		System.out.println("=============================");
	}
}

