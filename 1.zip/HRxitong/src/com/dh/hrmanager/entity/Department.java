package com.dh.hrmanager.entity;

public class Department {
	private int departId;
	private String name;
	public Department() {

	}
	public Department(int departId, String name) {
		this.departId = departId;
		this.name = name;
	}
	public int getDepartId() {
		return departId;
	}
	public void setDepartId(int departId) {
		this.departId = departId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return name;
	}

}
