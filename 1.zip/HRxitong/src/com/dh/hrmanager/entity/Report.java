package com.dh.hrmanager.entity;


//�㱨��
public class Report {
 //�㱨ID
	private int reportId;
	//�㱨��ID
	private int reporterId;
	//�㱨����
	private String content;
	public Report(){
	}
	public Report(int reportId, int reporterId, String content){
		this.reporterId = reporterId;
		this.reportId = reportId;
		this.content = content;
	}

	public int getReportId() {
		return reportId;
	}
	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	public int getReporterId() {
		return reporterId;
	}
	public void setReporterId(int reporterId) {
		this.reporterId = reporterId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
