package com.dh.hrmanager.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JComboBox;

import com.dh.hrmanager.entity.Department;
import com.dh.hrmanager.util.DBUtil;

public class DepartmentDao {
	public int getDepartIdByDepartName(String departName) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		String strSql = "SELECT HR_DEPARTMENT.DEPARTID FROM HR_DEPARTMENT WHERE NAME = ?";
		String[] parameters = new String[]{
				departName	
		};
		//ʵ�������ݿ⹤��
		DBUtil dbUtil = new DBUtil();
		//�����ݿ⣬��ȡ���Ӷ���
		dbUtil.getConnection();
		//�鿴�Ƿ���ڵ�½�˺�
		ResultSet rs = dbUtil.executeQuery(strSql, parameters);
		int result = 0;
		if(rs.next())
			result = rs.getInt(1);
		dbUtil.closeAll();
		return result;
	}
	
	public String getDepartmentNameById(int departId) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		String strSql = "SELECT HR_DEPARTMENT.NAME FROM HR_DEPARTMENT WHERE DEPARTID = ?";
		String[] parameters = new String[]{
				String.valueOf(departId)	
		};
		//ʵ�������ݿ⹤��
		DBUtil dbUtil = new DBUtil();
		//�����ݿ⣬��ȡ���Ӷ���
		dbUtil.getConnection();
		String result = null;

		try{
			ResultSet rs = dbUtil.executeQuery(strSql, parameters);
			if(rs.next())
				result = rs.getString(1);
		}catch(SQLException ex){
			System.out.println(ex.getMessage());
		}finally{
			dbUtil.closeAll();
		}
		return result;
	}
	
	//��ȡ������Ϣ
	public void getDepartment(JComboBox cbx) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		String strSql = "SELECT DEPARTID, NAME FROM HR_DEPARTMENT";
		DBUtil dbUtil = new DBUtil();
		dbUtil.getConnection();
		ResultSet rs = dbUtil.executeQuery(strSql, null);
		//cbx.removeAll();		
		while(rs.next()){
			cbx.addItem(new Department(rs.getInt(1), rs.getString(2)));
		}
		dbUtil.closeAll();
	}
//	//��ȡ���в���
//	public ArrayList<Department> getDepartments() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
//		String strSql = "SELECT DEPARTID, NAME FROM HR_DEPARTMENT";
//		DBUtil dbUtil = new DBUtil();
//		dbUtil.getConnection();
//		ResultSet rs = dbUtil.executeQuery(strSql, null);
//		ArrayList<Department> list = new ArrayList<Department>();	
//		while(rs.next()){
//			list.add(new Department(rs.getInt(1), rs.getString(2)));
//		}
//		dbUtil.closeAll();
//		return list;
//	}
}
