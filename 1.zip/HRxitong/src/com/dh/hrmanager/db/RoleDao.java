package com.dh.hrmanager.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JComboBox;

import com.dh.hrmanager.entity.Role;
import com.dh.hrmanager.util.DBUtil;

public class RoleDao {
	public String getRoleNameById(int roleId) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
	String strSql = "SELECT HR_ROLE.ROLENAME FROM HR_ROLE WHERE ROLEID = ?";
		String[] parameters = new String[]{
				String.valueOf(roleId)	
		};
		//ʵ�������ݿ⹤��
		DBUtil dbUtil = new DBUtil();
		//�����ݿ⣬��ȡ���Ӷ���
		dbUtil.getConnection();
		String result = null;

		try{
			ResultSet rs = dbUtil.executeQuery(strSql, parameters);
			if(rs.next())
				result = rs.getString(1);
		}catch(SQLException ex){
			System.out.println(ex.getMessage());
		}finally{
			dbUtil.closeAll();
		}
		return result;
	}
	
	//��ȡ��ɫ��Ϣ
		public void getRoles(JComboBox cbx) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
			String strSql = "SELECT ROLEID, ROLENAME FROM HR_ROLE";
			DBUtil dbUtil = new DBUtil();
			dbUtil.getConnection();
			ResultSet rs = dbUtil.executeQuery(strSql, null);
			//cbx.removeAll();		
			while(rs.next()){
				cbx.addItem(new Role(rs.getInt(1), rs.getString(2)));
			}
			dbUtil.closeAll();
		}
		
}
