package com.dh.hrmanager.db;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JTable;

import com.dh.hrmanager.entity.Admin;
import com.dh.hrmanager.entity.EditTable;
import com.dh.hrmanager.entity.Employee;
import com.dh.hrmanager.entity.Manager;
import com.dh.hrmanager.entity.Staff;
import com.dh.hrmanager.util.DBUtil;

public class UserDao {	
	//��½���,���ص�½�˵���Ϣ
public Employee loginByDb(String name, String password) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
	String strSql = " SELECT HR_USER.USERID, HR_USER.USERNAME, HR_USER.ROLEID, HR_USER.DEPARTID, HR_USER.SALARY, HR_USER.PASSWORD, HR_USER.EMPNO " +
					"   FROM HR_USER " +
					"  WHERE HR_USER.USERNAME = ? " +
					"    AND HR_USER.PASSWORD = ? ";	
	String[] parameters = new String[]{
			name,
			password
	};
	int roleId = 0;
	//ʵ�������ݿ⹤��
	DBUtil dbUtil = new DBUtil();
	//�����ݿ⣬��ȡ���Ӷ���
	dbUtil.getConnection();
	//�鿴�Ƿ���ڵ�½�˺�
	ResultSet rs = dbUtil.executeQuery(strSql, parameters);
	Employee employee = null;
	try{
		//��������û�,���ص�½��ɫ
		if(rs.next()){
			//�õ���ǰ��¼Ա������
			roleId = rs.getInt(3);
			int userId = rs.getInt(1);
			String empNo = rs.getString(7);
			String userName = rs.getString(2);
			int departId = rs.getInt(4);
			double salary = rs.getDouble(5);
			if(roleId == 1){
				employee = new Staff(userId, empNo, userName, password, departId, roleId, salary);
			}
			if(roleId == 2)
				employee = new Manager(userId, empNo, userName, password, departId, roleId, salary);
			if(roleId == 3)
				employee = new Admin(userId, empNo, userName, password, departId, roleId, salary);
		}
	}
	catch(SQLException ex){
		ex.printStackTrace();
	}finally{
		dbUtil.closeAll();
	}
	return employee;
}

//����Ա��ID�õ�Ա����Ϣ
public Employee getEmployeeByUserId(int userId) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
	String strSql = " SELECT HR_USER.USERID, HR_USER.USERNAME, HR_USER.ROLEID, HR_USER.DEPARTID, HR_USER.SALARY, HR_USER.PASSWORD, HR_USER.EMPNO " +
					"   FROM HR_USER " +
					"  WHERE HR_USER.USERID= ? ";
			String[] parameters = new String[]{
					String.valueOf(userId)
			};
			//ʵ�������ݿ⹤��
			DBUtil dbUtil = new DBUtil();
			//�����ݿ⣬��ȡ���Ӷ���
			dbUtil.getConnection();
			//�鿴�Ƿ���ڵ�½�˺�
			ResultSet rs = dbUtil.executeQuery(strSql, parameters);
			Employee employee = null;
			try{
				//��������û�,���ص�½��ɫ
			if(rs.next()){
				//�õ���ǰ��¼Ա������
					int roleId = rs.getInt(3);
					String empNo = rs.getString(7);
					String userName = rs.getString(2);
					int departId = rs.getInt(4);
					double salary = rs.getDouble(5);
					String password = rs.getString(6);
					if(roleId == 1){
						employee = new Staff(userId, empNo, userName, password, departId, roleId, salary);
					}
					if(roleId == 2)
						employee = new Manager(userId, empNo, userName, password, departId, roleId, salary);
					if(roleId == 3)
						employee = new Admin(userId, empNo, userName, password, departId, roleId, salary);
				}
			}
			catch(SQLException ex){
				ex.printStackTrace();
			}finally{
				dbUtil.closeAll();
			}
			return employee;
}

//����Ա����ŵõ�Ա����Ϣ
	public Employee getEmployeeByEmpNo(String empNo) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		String strSql = " SELECT HR_USER.USERID, HR_USER.USERNAME, HR_USER.ROLEID, HR_USER.DEPARTID, HR_USER.SALARY, HR_USER.PASSWORD, HR_USER.EMPNO " +
						"   FROM HR_USER " +
						"  WHERE HR_USER.EMPNO= ? ";
				String[] parameters = new String[]{
						empNo
				};
				//ʵ�������ݿ⹤��
				DBUtil dbUtil = new DBUtil();
				//�����ݿ⣬��ȡ���Ӷ���
				dbUtil.getConnection();
				//�鿴�Ƿ���ڵ�½�˺�
				ResultSet rs = dbUtil.executeQuery(strSql, parameters);
				Employee employee = null;
				try{
					//��������û�,���ص�½��ɫ
					if(rs.next()){
					//�õ���ǰ��¼Ա������
						int roleId = rs.getInt(3);
						int userId = rs.getInt(1);
						String userName = rs.getString(2);
						int departId = rs.getInt(4);
						double salary = rs.getDouble(5);
						String password = rs.getString(6);
						if(roleId == 1){
							employee = new Staff(userId, empNo, userName, password, departId, roleId, salary);
						}
						if(roleId == 2)
							employee = new Manager(userId, empNo, userName, password, departId, roleId, salary);
						if(roleId == 3)
							employee = new Admin(userId, empNo, userName, password, departId, roleId, salary);
					}
				}
				catch(SQLException ex){
					ex.printStackTrace();
				}finally{
					dbUtil.closeAll();
				}
				return employee;
	}



//�õ�Ա�����ڲ��ž���
public Manager getDepartmentManagerByUserId(int userId) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
	Manager manager  = null;
	String strSql = " SELECT HR_user.userid, " +
					"		 HR_user.username, " +
					"		 HR_user.password, " +
					"		 HR_user.roleid, " +
					"		 HR_user.empno, " +
					"		 HR_user.departid, " +
					"		 HR_user.salary, " +
					"		 HR_role.rolename " +
					"  FROM  HR_user, HR_role, " +
				    "		 (SELECT departid  " + "" +
				    " 		    FROM HR_user " + 
				    "		   WHERE userid = ?) s1 " +
				    " WHERE  HR_role.roleid = hr_user.roleid AND " +
				    "		 HR_role.rolename = 'Manager' AND " +
				    "		 HR_user.departid = s1.departid ";
	String[] parameters = {
		String.valueOf(userId)
	};
	DBUtil dbutil = new DBUtil();
	dbutil.getConnection();
	ResultSet rs = dbutil.executeQuery(strSql, parameters);
	try{
		if(rs.next()){
			String empNo = rs.getString(5);
			String userName = rs.getString(2);
			String password = rs.getString(3);
			int departId = rs.getInt(6);
			int roleId = rs.getInt(4);
			double salary = rs.getDouble(7);
			manager = new Manager(userId, empNo, userName, password, departId, roleId, salary);
		}
	}catch(SQLException ex){
		System.out.println(ex.getMessage());
	}finally{
		dbutil.closeAll();
	}
	return manager;
}

	//ע���˺�
	public boolean registerUser(String userName, String password, int roleId, String empNo, int departmentId, double salary){
		
		String strSql = " INSERT INTO HR_USER(USERID, USERNAME, PASSWORD, ROLEID, EMPNO, DEPARTID, SALARY) " +
						" 	VALUES(USER_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?)";
		//����ֵ����
		String[] parameters = new String[]{
				userName,
				password,
				String.valueOf(roleId),
				empNo,
				String.valueOf(departmentId),
				String.valueOf(salary)
		};
		//ʵ�������ݿ⹤��
		DBUtil dbUtil = new DBUtil();
		//�����ݿ⣬��ȡ���Ӷ���
		try {
			dbUtil.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		//�Ƿ�ɹ���־
		boolean successed = true;
		try{
			dbUtil.executeUpdate(strSql, parameters);
		}catch(Exception ex){
			successed = false;
		}finally{
			dbUtil.closeAll();
		}
		return successed;
	}
	//�޸�����
	public int modifyPassword(Employee emp, String newPassword) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		String strSql = "UPDATE HR_USER SET PASSWORD = ? WHERE USERID = ?";
		String[] parameters = {
			newPassword,
			String.valueOf(emp.getUserId())
		};
		DBUtil dbutil = new DBUtil();
		dbutil.getConnection();
		int result = dbutil.executeUpdate(strSql, parameters);
		dbutil.closeAll();
		return result;
	}
	//�õ�ָ����������Ա��, ������ű��<=0,����ѯ��˾������Ա��
	public ArrayList<Employee> getEmployeesByDepartId(int departId) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		ArrayList<Employee> reports = new ArrayList<Employee>();
		DBUtil dbUtil = new DBUtil();
		dbUtil.getConnection();
		String strSql = null;
		ResultSet rs = null;
		if(departId > 0){
			strSql = " SELECT HR_USER.USERID, HR_USER.USERNAME, HR_USER.ROLEID, HR_USER.DEPARTID, HR_USER.SALARY, HR_USER.PASSWORD, HR_USER.EMPNO " +
							"   FROM HR_USER " +
							"  WHERE HR_USER.DEPARTID = ? ";
			String[] parameters = {
				String.valueOf(departId)	
			};
			rs = dbUtil.executeQuery(strSql, parameters);
		}else{
			strSql = " SELECT HR_USER.USERID, HR_USER.USERNAME, HR_USER.ROLEID, HR_USER.DEPARTID, HR_USER.SALARY, HR_USER.PASSWORD, HR_USER.EMPNO " +
					"   FROM HR_USER " ;
			rs = dbUtil.executeQuery(strSql, null);
		}
	
		while(rs.next()){
			Employee employee = null;
			int userId = rs.getInt(1);
			int roleId = rs.getInt(3);
			String empNo = rs.getString(7);
			String userName = rs.getString(2);
			double salary = rs.getDouble(5);
			String password = rs.getString(6);
			int depId = rs.getInt(4);
			if(roleId == 1){
				employee = new Staff(userId, empNo, userName, password, depId, roleId, salary);
			}
			if(roleId == 2)
				employee = new Manager(userId, empNo, userName, password, depId, roleId, salary);
			if(roleId == 3)
				employee = new Admin(userId, empNo, userName, password, depId, roleId, salary);
			reports.add(employee);
		}
		dbUtil.closeAll();
		return reports;
	}
	
	//��Ա��������䵽����
	public void fillEmployeesToTable(int departId, JTable table, String[] titles) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		RoleDao rd = new RoleDao();
		DepartmentDao deptDao = new DepartmentDao();
		Vector<String> vctTitle = new Vector<String>();
		if(titles.length == 0)
			return;
		for(String item : titles)
			vctTitle.add(item);
				
		Vector<Vector<String>> vctDatas = new Vector<Vector<String>>();
		ArrayList<Employee> employees = getEmployeesByDepartId(departId);
		
		for(Employee employee : employees){
			Vector<String> vctRow = new Vector<String>();
			vctRow.add(employee.getEmpNo());
			vctRow.add(employee.getUserName());
			vctRow.add(rd.getRoleNameById(employee.getRoleId()));
			vctRow.add(deptDao.getDepartmentNameById(employee.getDepartId()));
			vctDatas.add(vctRow);
		}
		
		EditTable et = new EditTable(vctDatas, vctTitle);
		table.setModel(et);
	}
	
	//�����û���ɫ��Ϣ
	public void updateUserRole(int newRoleId, int userId) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException{
		String strSql = "UPDATE hr_user SET roleid = ? WHERE userid = ?";
			DBUtil dbutil = new DBUtil();
			dbutil.getConnection();
			String[] parameters = {
				String.valueOf(newRoleId),
				String.valueOf(userId)
			};
			dbutil.executeUpdate(strSql, parameters);
			dbutil.closeAll();
		}
}
