package com.dh.hrmanager.db;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JTable;

import com.dh.hrmanager.entity.EditTable;
import com.dh.hrmanager.entity.Employee;
import com.dh.hrmanager.entity.Report;
import com.dh.hrmanager.util.DBUtil;
public class ReportDao {
	UserDao userDao = new UserDao();
	//��ȡ���л㱨
	public ArrayList<Report> getReports() throws ClassNotFoundException, 
		SQLException, InstantiationException, IllegalAccessException{
		ArrayList<Report> reports = new ArrayList<Report>();
		String strSql = "SELECT REPORTID, REPORTERID, CONTENT,REPORTDATE"
				+ " FROM HR_REPORT ORDER BY REPORTID DESC";
		DBUtil util = new DBUtil();
		util.getConnection();
		ResultSet rs = util.executeQuery(strSql, null);
		while(rs.next()){
			Report report = new Report(rs.getInt(1), rs.getInt(2), rs.getString(3),rs.getString(4));
			reports.add(report);
		}
		util.closeAll();
		return reports;
	}
	//��ȡ�������л㱨
	public ArrayList<Report> getReportsByUserId(int userId) throws 
		ClassNotFoundException, SQLException, InstantiationException, 
		IllegalAccessException{
		ArrayList<Report> reports = new ArrayList<Report>();
		String strSql = "SELECT REPORTID, REPORTERID, CONTENT,REPORTDATE"
				+ " FROM HR_REPORT "
				+ "WHERE REPORTERID = ?"
				+ " ORDER BY REPORTID DESC ";
		String[] parameters = {String.valueOf(userId)};
		DBUtil util = new DBUtil();
		util.getConnection();
		ResultSet rs = util.executeQuery(strSql, parameters);
		while(rs.next()){
			Report report = new Report(rs.getInt(1), rs.getInt(2), 
			rs.getString(3),rs.getString(4));
			reports.add(report);
		}
		util.closeAll();
		return reports;
	}
	//��ȡ���������л㱨
	public ArrayList<Report> getReportsByDepartId(int departId) throws 
		ClassNotFoundException, SQLException, InstantiationException, 
		IllegalAccessException{
		ArrayList<Report> reports = new ArrayList<Report>();
		String strSql = "SELECT HR_REPORT.REPORTID, HR_REPORT.REPORTERID, "
				      + "HR_REPORT.CONTENT, HR_REPORT.REPORTDATE " 
		               + "   FROM HR_REPORT " 
				      + "  WHERE HR_REPORT.REPORTERID IN "
				      + "(SELECT USERID FROM HR_USER WHERE DEPARTID = ?) ";
		String[] parameters = {String.valueOf(departId)};
		DBUtil util = new DBUtil();
		util.getConnection();
		ResultSet rs = util.executeQuery(strSql, parameters);
		while(rs.next()){
			Report report = new Report(rs.getInt(1), rs.getInt(2),
 rs.getString(3),rs.getString(4));
			reports.add(report);
		}
		util.closeAll();
		return reports;
	}
	//���ӻ㱨
	public int addReport(Report report) throws ClassNotFoundException, 
		SQLException, InstantiationException, IllegalAccessException{
		String strSql = "INSERT INTO HR_REPORT (REPORTID, REPORTERID, CONTENT,REPORTDATE) "
				+ "VALUES (REPORT_SEQ.NEXTVAL, ?, ?,?)";
		String[] parameters = {
			String.valueOf(report.getReporterId()),
			report.getContent(),
			LocalDate.now().toString()
			};
		DBUtil util = new DBUtil();
		util.getConnection();
		int result = util.executeUpdate(strSql, parameters);
		util.closeAll();
		return result;
	}
	//���㱨������䵽����
	public void fillReportsToTable(Employee emp, JTable table, String[] titles, int type) throws ClassNotFoundException, SQLException, 
		InstantiationException, IllegalAccessException{
		Vector<String> vctTitle = new Vector<String>();
		if(titles.length == 0)
			return;
		for(String item : titles)
			vctTitle.add(item);
		Vector<Vector<String>> vctDatas = new Vector<Vector<String>>();
		ArrayList<Report> reports = new ArrayList<Report>(); 
		switch(type){
			case 1:
				reports = getReportsByUserId(emp.getUserId());
				break;
			case 2:
				reports = getReportsByDepartId(emp.getDepartId());
				break;
			case 3:
				reports = getReports();
				break;
		}
		for(Report report : reports){
			Vector<String> vctRow = new Vector<String>();
			vctRow.add(userDao.getEmployeeByUserId(report.getReporterId())
				.getUserName());
			vctRow.add(report.getContent());
			vctRow.add(report.getReporterId());
			vctDatas.add(vctRow);
		}
		EditTable et = new EditTable(vctDatas, vctTitle);
		table.setModel(et);
	}
}
