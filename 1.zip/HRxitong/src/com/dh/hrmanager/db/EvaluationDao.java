package com.dh.hrmanager.db;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JTable;

import com.dh.hrmanager.entity.EditTable;
import com.dh.hrmanager.entity.Employee;
import com.dh.hrmanager.entity.Evaluation;
import com.dh.hrmanager.util.DBUtil;
public class EvaluationDao {
	UserDao userDao = new UserDao();
	public void addEvaluation(Evaluation eva) throws ClassNotFoundException, 
		SQLException, InstantiationException, IllegalAccessException{
		String strSql = " INSERT INTO HR_EVALUATION (EVALUATIONID, EVALUATORID, EVALUATEDID, SCORE,EVALUATIONDATE) "
				+ " VALUES(EVALUATION_SEQ.NEXTVAL, ?, ?, ?,?) ";
		DBUtil dbutil = new DBUtil();
		dbutil.getConnection();
		String[] parameters = {String.valueOf(eva.getEvaluatorId()),
			String.valueOf(eva.getEvaluatedId()),
			String.valueOf(eva.getScore()),
			LocalDate.now().toString()
		};
		dbutil.executeUpdate(strSql, parameters);
		dbutil.closeAll();
	}
	//��ȡԱ����������
	public ArrayList<Evaluation> getEvaluationsByUserId(int userId) throws 
		ClassNotFoundException, SQLException, InstantiationException, 
		IllegalAccessException{
		ArrayList<Evaluation> evaList = new ArrayList<Evaluation>();
		String strSql = "SELECT EVALUATIONID, EVALUATORID, EVALUATEDID,SCORE,EVALUATIONDATE "
				+ " FROM HR_EVALUATION WHERE EVALUATEDID = ? "
				+ " ORDER BY EVALUATIONID DESC";
		String[] parameters ={String.valueOf(userId)};
		DBUtil util = new DBUtil();
		util.getConnection();
		ResultSet rs = util.executeQuery(strSql, parameters);
		while(rs.next()){
			Evaluation eva = new Evaluation(rs.getInt(1), 
				rs.getInt(2), rs.getInt(3), rs.getDouble(4),rs.getString(5));
			evaList.add(eva);
		}
		util.closeAll();
		return evaList;
	}
	//������������䵽����
	public void fillReportsToTable(Employee emp, JTable table, String[] titles, 	int type) 
	throws ClassNotFoundException, SQLException, InstantiationException, 
		IllegalAccessException{
			Vector<String> vctTitle = new Vector<String>();
			if(titles.length == 0)
				return;
			for(String item : titles)
				vctTitle.add(item);
			Vector<Vector<String>> vctDatas = new Vector<Vector<String>>();
			ArrayList<Evaluation> evas =  
				getEvaluationsByUserId(emp.getUserId());
			for(Evaluation eva : evas){
				Vector<String> vctRow = new Vector<String>();
				//��������
				vctRow.add(userDao.getEmployeeByUserId(eva.getEvaluatedId())
					.getUserName());
				//����ɼ�
				vctRow.add(String.valueOf(eva.getScore()));
				//���⾭��
				vctRow.add(userDao.getEmployeeByUserId(eva.getEvaluatorId())
					.getUserName());
			   //����ʱ��
				vctRow.add(eva.getEvaluationDate());
				vctDatas.add(vctRow);
			}
			EditTable et = new EditTable(vctDatas, vctTitle);
			table.setModel(et);
		}
}
